wrike-reporter
==============

Basic project reporting, gathering data from Wrike via it's API and then generating an HTML email
